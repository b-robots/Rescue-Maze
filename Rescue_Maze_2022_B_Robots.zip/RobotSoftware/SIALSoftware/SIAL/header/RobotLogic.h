#pragma once

#include "AllDatatypes.h"

namespace SIAL
{
	namespace RobotLogic
	{
		void loop();
	}
}